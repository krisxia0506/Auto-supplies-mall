create definer = root@localhost view active as
select `books management`.`reader`.`reader_id`        AS `reader_id`,
       `books management`.`reader`.`reader_name`      AS `reader_name`,
       `books management`.`reader`.`reader_sex`       AS `reader_sex`,
       `books management`.`reader`.`reader_age`       AS `reader_age`,
       `books management`.`reader`.`reader_pro`       AS `reader_pro`,
       `books management`.`reader`.`reader_integrity` AS `reader_integrity`,
       `books management`.`reader`.`reader_borrow`    AS `reader_borrow`
from `books management`.`reader`
order by `books management`.`reader`.`reader_borrow` desc;


create
    definer = root@localhost procedure proc_return(IN reader_id int, IN book_id int, IN return_date datetime)
begin
DECLARE borrowdate datetime;
if(select payoff from ticket where ticket.reader_id =reader_id and
ticket.book_id=book_id)= 1 then /*判断是否交了罚单﹐1表示没有交*/
select 'please pay off the ticket';
else/*纪录归还项目到return_table 中，并且删除借书纪录*/
set borrowdate = (select borrow_date from borrow where borrow.reader_id =
reader_id and borrow.book_id = book_id);
insert into return_table
values(reader_id, book_id, borrowdate, return_date);
delete from borrow
where borrow.reader_id = reader_id and borrow.book_id = book_id;
end if;
end;


create
    definer = root@localhost function fun_get_booknum(book_id int) returns int
begin
return(select book_in from book where book.book_id = book_id);
end;


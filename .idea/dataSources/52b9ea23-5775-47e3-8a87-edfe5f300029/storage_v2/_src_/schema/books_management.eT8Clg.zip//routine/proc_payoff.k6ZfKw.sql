create
    definer = root@localhost procedure proc_payoff(IN readerid int, IN bookid int)
begin
update ticket
set payoff = 0
where ticket.reader_id = readerid and ticket.book_id = bookid;
select '上缴罚单成功';
end;


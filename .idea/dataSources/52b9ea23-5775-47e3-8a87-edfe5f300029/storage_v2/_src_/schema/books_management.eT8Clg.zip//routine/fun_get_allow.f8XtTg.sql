create
    definer = root@localhost function fun_get_allow(reader_id1 int) returns int
begin
-- SET @a=select max_num from reader,reader_sort where reader.reader_pro = reader_pro and reader.reader_id=reader_id;
return(
(select max_num from reader,reader_sort where reader.reader_pro = reader_sort.reader_pro and reader.reader_id=reader_id1)
-(select reader_borrow FROM reader WHERE reader_id=reader_id1)
);
end;


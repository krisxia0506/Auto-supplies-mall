create definer = root@localhost trigger trigger_credit
    after insert
    on ticket
    for each row
begin
if (select count(* ) from ticket where reader_id=new.reader_id)>5 then
update student set stu_integrity = 0 where reader_id = new.reader_id;
end if;
end;


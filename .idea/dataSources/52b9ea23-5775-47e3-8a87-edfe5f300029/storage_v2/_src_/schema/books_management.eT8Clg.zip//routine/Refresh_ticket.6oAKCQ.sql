create
    definer = root@localhost procedure Refresh_ticket(IN nowtime datetime)
BEGIN
DECLARE cur_date datetime;
SET cur_date=nowtime;
REPLACE INTO ticket(reader_id,book_id,over_date,ticket_fee,payoff)
SELECT reader_id,book_id,datediff(cur_date,borrow.expect_return_date),0.5*datediff(cur_date,borrow.expect_return_date),1
FROM borrow
WHERE cur_date>borrow.expect_return_date;
END;


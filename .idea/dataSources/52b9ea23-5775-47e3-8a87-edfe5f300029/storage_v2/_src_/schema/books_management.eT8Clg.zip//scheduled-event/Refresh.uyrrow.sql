create definer = root@localhost event Refresh on schedule
    every '1' DAY
        starts '2022-05-26 17:49:58'
    on completion preserve
    enable
    do
    call Refresh_ticket(getdate());


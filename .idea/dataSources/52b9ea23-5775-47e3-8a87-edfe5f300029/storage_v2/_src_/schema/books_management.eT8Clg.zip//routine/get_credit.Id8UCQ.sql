create
    definer = root@localhost function get_credit(reader_id int) returns int
begin
return(select reader_integrity from student where reader.reader_id = reader_id);
end;


create definer = root@localhost view reader_borrow_return as
select `books management`.`reader`.`reader_id`         AS `reader_id`,
       `books management`.`reader`.`reader_name`       AS `reader_name`,
       `books management`.`book`.`book_id`             AS `book_id`,
       `books management`.`book`.`book_name`           AS `book_name`,
       `books management`.`return_table`.`borrow_date` AS `borrow_date`,
       `books management`.`return_table`.`return_date` AS `return_date`
from ((`books management`.`reader` join `books management`.`book`) join `books management`.`return_table`)
where ((`books management`.`reader`.`reader_id` = `books management`.`return_table`.`reader_id`) and
       (`books management`.`book`.`book_id` = `books management`.`return_table`.`book_id`));


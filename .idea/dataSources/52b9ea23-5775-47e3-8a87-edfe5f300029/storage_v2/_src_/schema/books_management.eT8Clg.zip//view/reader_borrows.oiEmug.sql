create definer = root@localhost view reader_borrows as
select `books management`.`reader`.`reader_id`                       AS `reader_id`,
       `books management`.`book`.`book_id`                           AS `book_id`,
       `books management`.`reader`.`reader_name`                     AS `reader_name`,
       `books management`.`book`.`book_name`                         AS `book_name`,
       `books management`.`borrow`.`borrow_date`                     AS `borrow_date`,
       (`books management`.`borrow`.`borrow_date` + interval 30 day) AS `expect_return_date`
from ((`books management`.`reader` join `books management`.`borrow`) join `books management`.`book`)
where ((`books management`.`reader`.`reader_id` = `books management`.`borrow`.`reader_id`) and
       (`books management`.`book`.`book_id` = `books management`.`borrow`.`book_id`));


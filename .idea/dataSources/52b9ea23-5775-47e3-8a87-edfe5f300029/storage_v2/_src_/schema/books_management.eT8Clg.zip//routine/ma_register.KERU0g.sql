create
    definer = root@localhost procedure ma_register(IN ma_id int, IN ma_name varchar(10), IN ma_age int, IN ma_phone int)
BEGIN
insert into manager
values(manager_id, manager_name, manager_age, manager_phone);
END;


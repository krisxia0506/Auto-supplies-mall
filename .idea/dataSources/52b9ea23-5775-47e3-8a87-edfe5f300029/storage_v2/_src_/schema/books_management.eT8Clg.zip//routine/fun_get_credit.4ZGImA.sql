create
    definer = root@localhost function fun_get_credit(reader_id int) returns int
begin
return(select reader_integrity from reader where reader.reader_id = reader_id);
end;


create
    definer = root@localhost procedure reader_register(IN reader_id int, IN reader_name varchar(10),
                                                       IN reader_sex varchar(10), IN reader_pro varchar(10),
                                                       IN reader_intergrity int, IN readr_borrow int)
begin
insert into reader(reader_id, reader_name, reader_sex, reader_pro, reader_intergrity,readr_borrow)
values(reader_id,reader_name,reader_sex,reader_pro, reader_intergrity,readr_borrow);
end;


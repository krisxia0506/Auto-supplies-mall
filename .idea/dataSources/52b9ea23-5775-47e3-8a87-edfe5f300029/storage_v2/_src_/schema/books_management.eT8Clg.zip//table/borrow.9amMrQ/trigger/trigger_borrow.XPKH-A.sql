create definer = root@localhost trigger trigger_borrow
    after insert
    on borrow
    for each row
BEGIN
UPDATE book SET book_in=book_in-1
WHERE book_id=new.book_id;
UPDATE reader SET reader_borrow=reader_borrow+1
WHERE reader_id=new.reader_id;
END;


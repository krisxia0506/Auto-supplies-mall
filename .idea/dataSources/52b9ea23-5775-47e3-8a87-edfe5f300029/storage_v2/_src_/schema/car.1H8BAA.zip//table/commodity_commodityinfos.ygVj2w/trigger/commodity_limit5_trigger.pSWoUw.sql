create definer = root@localhost trigger commodity_limit5_trigger
    after update
    on commodity_commodityinfos
    for each row
begin
    if old.stock > new.stock then
    update commodity_sold set sold = sold + 1 where id = new.id;
    end if;
END;


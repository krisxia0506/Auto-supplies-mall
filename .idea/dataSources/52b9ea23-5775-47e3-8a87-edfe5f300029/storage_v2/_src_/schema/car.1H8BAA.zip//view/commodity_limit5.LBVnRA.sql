create definer = root@localhost view commodity_limit5 as
select `ccct0`.`id`     AS `id`,
       `ccct0`.`img`    AS `img`,
       `ccct0`.`name`   AS `name`,
       `ccct0`.`sold`   AS `sold`,
       `ccct0`.`types`  AS `types`,
       `ccct0`.`firsts` AS `firsts`
from (select `babys`.`commodity_commodityinfos`.`id`    AS `id`,
             `babys`.`commodity_commodityinfos`.`img`   AS `img`,
             `babys`.`commodity_commodityinfos`.`name`  AS `name`,
             `babys`.`commodity_commodityinfos`.`sold`  AS `sold`,
             `babys`.`commodity_commodityinfos`.`types` AS `types`,
             `babys`.`commodity_types`.`firsts`         AS `firsts`
      from (`babys`.`commodity_commodityinfos` join `babys`.`commodity_types`
            on ((`babys`.`commodity_commodityinfos`.`types` = `babys`.`commodity_types`.`seconds`)))
      where (`babys`.`commodity_types`.`firsts` = '行车安全')
      order by `babys`.`commodity_commodityinfos`.`sold` desc
      limit 5) `ccct0`
union all
select `ccct1`.`id`     AS `id`,
       `ccct1`.`img`    AS `img`,
       `ccct1`.`name`   AS `name`,
       `ccct1`.`sold`   AS `sold`,
       `ccct1`.`types`  AS `types`,
       `ccct1`.`firsts` AS `firsts`
from (select `babys`.`commodity_commodityinfos`.`id`    AS `id`,
             `babys`.`commodity_commodityinfos`.`img`   AS `img`,
             `babys`.`commodity_commodityinfos`.`name`  AS `name`,
             `babys`.`commodity_commodityinfos`.`sold`  AS `sold`,
             `babys`.`commodity_commodityinfos`.`types` AS `types`,
             `babys`.`commodity_types`.`firsts`         AS `firsts`
      from (`babys`.`commodity_commodityinfos` join `babys`.`commodity_types`
            on ((`babys`.`commodity_commodityinfos`.`types` = `babys`.`commodity_types`.`seconds`)))
      where (`babys`.`commodity_types`.`firsts` = '用车舒适')
      order by `babys`.`commodity_commodityinfos`.`sold` desc
      limit 5) `ccct1`
union all
select `ccct2`.`id`     AS `id`,
       `ccct2`.`img`    AS `img`,
       `ccct2`.`name`   AS `name`,
       `ccct2`.`sold`   AS `sold`,
       `ccct2`.`types`  AS `types`,
       `ccct2`.`firsts` AS `firsts`
from (select `babys`.`commodity_commodityinfos`.`id`    AS `id`,
             `babys`.`commodity_commodityinfos`.`img`   AS `img`,
             `babys`.`commodity_commodityinfos`.`name`  AS `name`,
             `babys`.`commodity_commodityinfos`.`sold`  AS `sold`,
             `babys`.`commodity_commodityinfos`.`types` AS `types`,
             `babys`.`commodity_types`.`firsts`         AS `firsts`
      from (`babys`.`commodity_commodityinfos` join `babys`.`commodity_types`
            on ((`babys`.`commodity_commodityinfos`.`types` = `babys`.`commodity_types`.`seconds`)))
      where (`babys`.`commodity_types`.`firsts` = '车内配件')
      order by `babys`.`commodity_commodityinfos`.`sold` desc
      limit 5) `ccct2`;


create
    definer = root@localhost procedure commodity_sold_procedure()
begin
    select id,img,name,discount,price from commodity_commodityinfos
    order by sold desc
    limit 8;
end;


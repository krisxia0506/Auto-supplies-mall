create definer = root@localhost trigger commodity_limit5_trigger
    after update
    on commodity_commodityinfos
    for each row
begin
    if old.sold > new.sold then
        insert into commodity_sold(id, name, sezes, types, price)
    values (OLD.id, OLD.name, OLD.sezes, OLD.types, OLD.price);
    end if;
END;

